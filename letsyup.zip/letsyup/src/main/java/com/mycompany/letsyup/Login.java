/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.letsyup;

/**login class
 * We will use a class to store the users details, and use methods to validate credentials.
 * @author julie
 */
public class Login {

    //Login Class
    public String username;
    public String password;
    public String phoneNumber;

    public Login(String username, String password, String phoneNumber) {
        this.username = username;
        this.password = password;
        this.phoneNumber = phoneNumber;
    }

    // Check username.
    // Check username not be more than 5 characters long.
    // Username contains an underscore.
    public boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    // Check password complexity.
    // Password should be 8 characters long.
    // Password contain a special character.
    public boolean checkPasswordComplexity(String password) {
        return password.length() >= 8 &&
               password.matches(".*[A-Z].*") &&
               password.matches(".*\\d.*") &&
               password.matches(".*[!@#$%^&*(),.?':{}|<>].*");
    }

    // Check SA cellphone number
    public boolean checkCellPhoneNumber(String phoneNumber) {
        String regex = "\\+27[6-8]\\d{8}";
        return phoneNumber.matches(regex);
    }

    // Login check
    public boolean loginUser(String enteredPassword) {
        return this.password.equals(enteredPassword);
    }

    // Login message
    public String returnLoginStatus() {
        return "Welcome " + username + ", it is great to see you again.";
    }

    // Retriving the username
    public String getUsername() {
        return username;
    }
}