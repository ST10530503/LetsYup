/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.letsyup;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author julie
 */
public class Letsyup {

public static void main(String[] args) {

        //User input
        Scanner scanner = new Scanner(System.in);
        ArrayList<Login> users = new ArrayList<>();

        System.out.println("\nHello, welcome to LetsYup!");

        while (true) {

            //Display menu - selection
            System.out.println("\nMain Menu");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {

                case 1 -> {
                    //Registration takes place
                    System.out.print("Enter username: ");
                    String username = scanner.nextLine();

                    System.out.print("Enter password: ");
                    String password = scanner.nextLine();

                    System.out.print("Enter South African number (e.g. +27670259061): ");
                    String phoneNumber = scanner.nextLine();

                    // Login feature after registration, validate 
                    Login tempUser = new Login(username, password, phoneNumber);

                    if (!tempUser.checkUserName(username)) {
                        System.out.println("Username is not correctly formatted, please ensure it contains an underscore and is no more than 5 characters.");
                        break;
                    }
                    
                    // username input - 5 characters or less
                    System.out.println("Username successfully captured!");

                    if (!tempUser.checkPasswordComplexity(password)) {
                        System.out.println("Password is not correctly formatted, please ensure it contains at least 8 characters, a capital letter, a number and a special character.");
                        break;
                    }

                    // password input - 8 characters long 
                    System.out.println("Password successfully captured!");

                    if (!tempUser.checkCellPhoneNumber(phoneNumber)) {
                        System.out.println("Cell phone number incorrectly formatted or does not contain international code.");
                        break;
                    }

                    // cellphone number with regex 
                    System.out.println("Cellphone number successfully added!");

                    boolean userExists = users.stream()
                            .anyMatch(u -> u.getUsername().equals(username));

                    if (userExists) {
                        System.out.println("Username already exists. Please choose another.");
                        break;
                    }

                    users.add(tempUser);
                    
                    // success page, go to login 
                    System.out.println("User registered successfully!");
                    System.out.println("Welcome " + username + "! You can login now.");
                }

                case 2 -> {

                    // check is user is registered, ask user to register
                    if (users.isEmpty()) {
                        System.out.println("No users registered yet. Please register first.");
                        break;
                    }

                    promptLogin(scanner, users);

                }

                case 3 -> {

                    // exit page
                    System.out.println("Goodbye!");
                    scanner.close();
                    return;

                }

                default -> System.out.println("Invalid option. Please choose 1, 2, or 3.");

            }
        }
    }

    private static void promptLogin(Scanner scanner, ArrayList<Login> users) {

        // Login page - must match credentials used on registration
        System.out.print("Enter username: ");
        String enteredUsername = scanner.nextLine();

        System.out.print("Enter password: ");
        String enteredPassword = scanner.nextLine();

        Login user = users.stream()
                .filter(u -> u.getUsername().equals(enteredUsername))
                .findFirst()
                .orElse(null);

        boolean loginStatus = user != null && user.loginUser(enteredPassword);

        if (loginStatus) {
            System.out.println(user.returnLoginStatus());
        } else {
            System.out.println("Invalid username or password.");
        }
    }
}
    

