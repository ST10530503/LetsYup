/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.letsyup;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author julie
 */

public class LoginTest {

    @Test
    public void testCheckUserNameValid() {

        Login user = new Login("J_u1s", "Password1!", "+27838968976");

        boolean result = user.checkUserName("J_u1s");

        assertTrue(result);

    }

    @Test
    public void testCheckUserNameInvalid() {

        Login user = new Login("Juls!!!!!!!", "Password1!", "+27838968976");

        boolean result = user.checkUserName("Juls!!!!!!!");

        assertFalse(result);

    }

    @Test
    public void testCheckPasswordComplexityValid() {

        Login user = new Login("J_u1s", "Ch&sec@ke99!", "+27838968976");

        boolean result = user.checkPasswordComplexity("Ch&sec@ke99!");

        assertTrue(result);

    }

    @Test
    public void testCheckPasswordComplexityInvalid() {

        Login user = new Login("J_u1s", "password", "+27838968976");

        boolean result = user.checkPasswordComplexity("password");

        assertFalse(result);

    }

    @Test
    public void testCheckCellPhoneNumberValid() {

        Login user = new Login("J_u1s", "Password1!", "+27838968976");

        boolean result = user.checkCellPhoneNumber("+27838968976");

        assertTrue(result);

    }

    @Test
    public void testCheckCellPhoneNumberInvalid() {

        Login user = new Login("j_u1s", "Password1!", "08966553");

        boolean result = user.checkCellPhoneNumber("08966553");

        assertFalse(result);

    }
}